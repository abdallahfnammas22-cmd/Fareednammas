BTEC Engineering Website Demo

Files:
- index.html
- style.css
- script.js

How to use:
1. Extract the ZIP file.
2. Open index.html in your browser.
3. Navigate between pages using the sidebar.
4. Ask questions in the BTEC Assistant section.

Notes:
- This is a static student-focused website demo.
- The assistant is intentionally restricted to BTEC Engineering topics only.
- Images are loaded from public image URLs.
- Made by Fareed Saeed Nammas.
