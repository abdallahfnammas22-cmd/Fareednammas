const volume1Units = [
  {
    id: "u1",
    title: "الوحدة 1: العمل بأمان وفاعلية في الورشة الهندسية",
    summary: "تركز على إجراءات السلامة، الحوادث والطوارئ، معدات الوقاية الشخصية، تقييم المخاطر، وإعداد بيئة العمل الهندسية بشكل آمن.",
    image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&w=1200&q=80",
    emoji: "🦺"
  },
  {
    id: "u2",
    title: "الوحدة 2: مهارات التفكير في المشكلات الهندسية وابتكار الحلول",
    summary: "تدعم التفكير التحليلي وحل المشكلات واختيار الحلول العملية في السياقات الهندسية.",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80",
    emoji: "🧠"
  },
  {
    id: "u3",
    title: "الوحدة 3: التحقق من منتج هندسي",
    summary: "تركز على فحص المنتج والتحقق من الجودة والمتطلبات الهندسية الأساسية.",
    image: "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=1200&q=80",
    emoji: "✅"
  },
  {
    id: "u4",
    title: "الوحدة 4: الصيانة الهندسية",
    summary: "تعرض مفاهيم الصيانة الوقائية والتشغيل الآمن والحفاظ على المعدات والأنظمة.",
    image: "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?auto=format&fit=crop&w=1200&q=80",
    emoji: "🔧"
  }
];

const volume2Units = [
  {
    id: "u5",
    title: "الوحدة 5: الرياضيات لفنيي الهندسة",
    summary: "تشمل الحسابات، الجبر، الرسوم البيانية، القياس، وحساب المثلثات لحل المسائل الهندسية.",
    image: "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=1200&q=80",
    emoji: "📐"
  },
  {
    id: "u6",
    title: "الوحدة 6: المواد الهندسية",
    summary: "توضح أنواع المواد وخصائصها واستخداماتها في التطبيقات الهندسية.",
    image: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=1200&q=80",
    emoji: "🧱"
  },
  {
    id: "u7",
    title: "الوحدة 7: الرسم الهندسي",
    summary: "تتناول قراءة الرسومات الهندسية وإعدادها وفهم الأبعاد والرموز الأساسية.",
    image: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=1200&q=80",
    emoji: "✏️"
  },
  {
    id: "u11",
    title: "الوحدة 11: اللحام",
    summary: "تعرض أساسيات اللحام، أنواع العمليات، السلامة، والتطبيقات العملية.",
    image: "https://images.unsplash.com/photo-1565431108756-6a4d3f9fb8ba?auto=format&fit=crop&w=1200&q=80",
    emoji: "🔥"
  },
  {
    id: "u12",
    title: "الوحدة 12: تقنيات تحسين الأعمال",
    summary: "تركز على الجودة، التحسين المستمر، والكفاءة في بيئة العمل المهنية.",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80",
    emoji: "📈"
  },
  {
    id: "u20",
    title: "الوحدة 20: العلوم الكهربائية والميكانيكية للهندسة",
    summary: "تجمع بين المفاهيم الكهربائية والميكانيكية المستخدمة في الممارسات الهندسية.",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80",
    emoji: "⚡"
  },
  {
    id: "u22",
    title: "الوحدة 22: إنشاء الدوائر الكهربائية والإلكترونية واختبارها",
    summary: "توضح بناء الدوائر، الاختبار، القياس، وفهم سلوك المكونات الكهربائية والإلكترونية.",
    image: "https://images.unsplash.com/photo-1553406830-ef2513450d76?auto=format&fit=crop&w=1200&q=80",
    emoji: "💡"
  },
  {
    id: "u24",
    title: "الوحدة 24: تشغيل وصيانة الأنظمة والمكونات الكهربائية والإلكترونية",
    summary: "تركز على التشغيل الآمن والصيانة العملية للمكونات والأنظمة.",
    image: "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=1200&q=80",
    emoji: "🛠️"
  },
  {
    id: "u27",
    title: "الوحدة 27: البرمجة العامة",
    summary: "تعرض أساسيات البرمجة والمنطق والخوارزميات في السياقات التقنية.",
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=1200&q=80",
    emoji: "💻"
  },
  {
    id: "u31",
    title: "الوحدة 31: تقنيات صيانة المركبات",
    summary: "تتناول صيانة المركبات، الفحص، التشخيص، والخدمة العملية.",
    image: "https://images.unsplash.com/photo-1487754180451-c456f719a1fc?auto=format&fit=crop&w=1200&q=80",
    emoji: "🚗"
  }
];

const knowledgeBase = [
  {
    keywords: ["السلامة", "ppe", "معدات الوقاية", "ورشة", "مخاطر", "حوادث"],
    answer: "بحسب منهج BTEC في الهندسة، السلامة في الورشة تشمل تقييم المخاطر، اتباع إجراءات الطوارئ، استخدام معدات الوقاية الشخصية المناسبة، والتأكد من خلو منطقة العمل من الأخطار قبل البدء."
  },
  {
    keywords: ["رياضيات", "math", "مثلثات", "قياس", "graph", "جبر"],
    answer: "وحدة الرياضيات لفنيي الهندسة تغطي الحسابات الأساسية، BIDMAS، الكسور والأعداد العشرية، الجبر، الرسوم البيانية، القياس، وحساب المثلثات لحل المسائل الهندسية."
  },
  {
    keywords: ["رسم", "drawing", "الرسم الهندسي", "أبعاد", "dimension"],
    answer: "وحدة الرسم الهندسي تركز على قراءة الرسومات، فهم الأبعاد والرموز، واستخدام الرسم كوسيلة أساسية للتواصل الفني داخل التخصصات الهندسية."
  },
  {
    keywords: ["لحام", "welding"],
    answer: "وحدة اللحام تشمل مبادئ اللحام، إجراءات السلامة، أنواع العمليات، وفهم الاستخدامات العملية في البيئات المهنية."
  },
  {
    keywords: ["دوائر", "circuit", "الكترون", "electrical", "مقاومة", "جهد", "تيار"],
    answer: "المحتوى الكهربائي في BTEC يغطي بناء الدوائر الكهربائية والإلكترونية، اختبارها، ومفاهيم مثل الجهد والتيار والمقاومة، إضافة إلى تشغيل وصيانة الأنظمة الكهربائية والإلكترونية."
  },
  {
    keywords: ["مركبات", "سيارات", "vehicle", "صيانة المركبات"],
    answer: "وحدة صيانة المركبات تركز على الفحص والخدمة والصيانة وتشخيص الأعطال ضمن إطار مهني عملي."
  },
  {
    keywords: ["تحسين", "quality", "business improvement", "جودة"],
    answer: "تقنيات تحسين الأعمال في BTEC تهدف إلى رفع الكفاءة، دعم الجودة، وتقليل الهدر وتحسين الأداء داخل العمليات المهنية."
  },
  {
    keywords: ["برمجة", "programming", "code"],
    answer: "وحدة البرمجة العامة تقدم أساسيات التفكير البرمجي، بناء الخوارزميات، والمنطق البرمجي بصورة مناسبة للمسار المهني."
  }
];

const quickQuestions = [
  "ما أهم قواعد السلامة في الورشة؟",
  "اشرح لي ماذا أدرس في وحدة الرياضيات لفنيي الهندسة",
  "ما الفرق بين الرسم الهندسي والدوائر الكهربائية في المنهج؟",
  "ما الذي أتعلمه في صيانة المركبات؟"
];

const allUnits = [...volume1Units, ...volume2Units];

function matchAnswer(question) {
  const q = question.toLowerCase();
  const hit = knowledgeBase.find((item) =>
    item.keywords.some((keyword) => q.includes(keyword.toLowerCase()))
  );

  if (hit) return hit.answer;

  return "أنا مساعد BTEC مخصص فقط لمحتوى الهندسة الموجود في المنهج المرفوع. اسألني عن السلامة، الرياضيات الهندسية، المواد الهندسية، الرسم الهندسي، اللحام، الدوائر الكهربائية والإلكترونية، البرمجة، أو صيانة المركبات.";
}

function renderHomeUnits() {
  const container = document.getElementById("homeUnits");
  container.innerHTML = allUnits.slice(0, 8).map(unit => `
    <article class="unit-card">
      <div class="unit-thumb">
        <img src="${unit.image}" alt="${unit.title}">
        <div class="emoji">${unit.emoji}</div>
      </div>
      <div class="unit-body">
        <h4>${unit.title}</h4>
        <p>${unit.summary}</p>
      </div>
    </article>
  `).join("");
}

function renderMaterials(items = allUnits) {
  const grid = document.getElementById("materialsGrid");
  grid.innerHTML = items.map(unit => `
    <article class="material-card">
      <div class="material-thumb">
        <img src="${unit.image}" alt="${unit.title}">
        <div class="emoji">${unit.emoji}</div>
      </div>
      <div class="material-body">
        <h3>${unit.title}</h3>
        <p>${unit.summary}</p>
      </div>
    </article>
  `).join("");
}

function renderQuickQuestions() {
  document.getElementById("quickQuestions").innerHTML = quickQuestions.map(q => `
    <div class="small-card">${q}</div>
  `).join("");

  document.getElementById("readyQuestions").innerHTML = quickQuestions.map(q => `
    <button class="ready-q" data-question="${q}">${q}</button>
  `).join("");
}

function addChatMessage(text, role) {
  const chatBox = document.getElementById("chatBox");
  const div = document.createElement("div");
  div.className = `chat-message ${role}`;
  div.textContent = text;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function sendQuestion(text) {
  const input = document.getElementById("chatInput");
  const question = (text ?? input.value).trim();
  if (!question) return;
  addChatMessage(question, "user");
  addChatMessage(matchAnswer(question), "assistant");
  input.value = "";
}

function setupNavigation() {
  const navButtons = document.querySelectorAll(".nav-btn");
  const pages = document.querySelectorAll(".page");

  navButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      navButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const pageId = btn.dataset.page;
      pages.forEach(page => page.classList.toggle("active", page.id === pageId));
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  });

  document.querySelectorAll(".go-assistant").forEach(btn => btn.addEventListener("click", () => navTo("assistant")));
  document.querySelectorAll(".go-materials").forEach(btn => btn.addEventListener("click", () => navTo("materials")));
}

function navTo(pageId) {
  document.querySelectorAll(".nav-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.page === pageId);
  });
  document.querySelectorAll(".page").forEach(page => {
    page.classList.toggle("active", page.id === pageId);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function setupRoles() {
  document.querySelectorAll(".role-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".role-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });
}

function setupSearch() {
  const input = document.getElementById("searchInput");
  input.addEventListener("input", () => {
    const value = input.value.trim();
    if (!value) return renderMaterials();
    const filtered = allUnits.filter(item => item.title.includes(value) || item.summary.includes(value));
    renderMaterials(filtered);
  });
}

function setupAssistant() {
  addChatMessage("مرحباً، أنا مساعد BTEC Engineering. أجيب فقط عن محتوى الوحدات الموجودة في الكتب المرفوعة. اكتب سؤالك الآن.", "assistant");
  document.getElementById("sendBtn").addEventListener("click", () => sendQuestion());
  document.getElementById("chatInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendQuestion();
  });
  document.addEventListener("click", (e) => {
    if (e.target.matches(".ready-q")) sendQuestion(e.target.dataset.question);
  });
}

renderHomeUnits();
renderMaterials();
renderQuickQuestions();
setupNavigation();
setupRoles();
setupSearch();
setupAssistant();
