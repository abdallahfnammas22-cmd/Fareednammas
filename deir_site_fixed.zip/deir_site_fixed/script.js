const volume1Units = [
  {
    id: "u1",
    title: "الوحدة 1: العمل بأمان وفاعلية في الورشة الهندسية",
    summary: "تركز على إجراءات السلامة، الحوادث والطوارئ، معدات الوقاية الشخصية، تقييم المخاطر، وإعداد بيئة العمل الهندسية بشكل آمن."
  },
  {
    id: "u2",
    title: "الوحدة 2: مهارات التفكير في المشكلات الهندسية وابتكار الحلول",
    summary: "تدعم التفكير التحليلي وحل المشكلات واختيار الحلول العملية في السياقات الهندسية."
  },
  {
    id: "u3",
    title: "الوحدة 3: التحقق من منتج هندسي",
    summary: "تركز على فحص المنتج والتحقق من الجودة والمتطلبات الهندسية الأساسية."
  },
  {
    id: "u4",
    title: "الوحدة 4: الصيانة الهندسية",
    summary: "تعرض مفاهيم الصيانة الوقائية والتشغيل الآمن والحفاظ على المعدات والأنظمة."
  }
];

const volume2Units = [
  {
    id: "u5",
    title: "الوحدة 5: الرياضيات لفنيي الهندسة",
    summary: "تشمل الحسابات، الجبر، الرسوم البيانية، القياس، وحساب المثلثات لحل المسائل الهندسية."
  },
  {
    id: "u6",
    title: "الوحدة 6: المواد الهندسية",
    summary: "توضح أنواع المواد وخصائصها واستخداماتها في التطبيقات الهندسية."
  },
  {
    id: "u7",
    title: "الوحدة 7: الرسم الهندسي",
    summary: "تتناول قراءة الرسومات الهندسية وإعدادها وفهم الأبعاد والرموز الأساسية."
  },
  {
    id: "u11",
    title: "الوحدة 11: اللحام",
    summary: "تعرض أساسيات اللحام، أنواع العمليات، السلامة، والتطبيقات العملية."
  },
  {
    id: "u12",
    title: "الوحدة 12: تقنيات تحسين الأعمال",
    summary: "تركز على الجودة، التحسين المستمر، والكفاءة في بيئة العمل المهنية."
  },
  {
    id: "u20",
    title: "الوحدة 20: العلوم الكهربائية والميكانيكية للهندسة",
    summary: "تجمع بين المفاهيم الكهربائية والميكانيكية المستخدمة في الممارسات الهندسية."
  },
  {
    id: "u22",
    title: "الوحدة 22: إنشاء الدوائر الكهربائية والإلكترونية واختبارها",
    summary: "توضح بناء الدوائر، الاختبار، القياس، وفهم سلوك المكونات الكهربائية والإلكترونية."
  },
  {
    id: "u24",
    title: "الوحدة 24: تشغيل وصيانة الأنظمة والمكونات الكهربائية والإلكترونية",
    summary: "تركز على التشغيل الآمن والصيانة العملية للمكونات والأنظمة."
  },
  {
    id: "u27",
    title: "الوحدة 27: البرمجة العامة",
    summary: "تعرض أساسيات البرمجة والمنطق والخوارزميات في السياقات التقنية."
  },
  {
    id: "u31",
    title: "الوحدة 31: تقنيات صيانة المركبات",
    summary: "تتناول صيانة المركبات، الفحص، التشخيص، والخدمة العملية."
  }
];

const quickQuestions = [
  "ما أهم قواعد السلامة في الورشة؟",
  "اشرح لي ماذا أدرس في وحدة الرياضيات لفنيي الهندسة",
  "ما الفرق بين الرسم الهندسي والدوائر الكهربائية في المنهج؟",
  "ما الذي أتعلمه في صيانة المركبات؟"
];

const knowledgeBase = [
  {
    keywords: ["السلامة", "ppe", "معدات الوقاية", "ورشة", "مخاطر", "حوادث"],
    answer: "بحسب منهج BTEC في الهندسة، السلامة في الورشة تشمل تقييم المخاطر، اتباع إجراءات الطوارئ، استخدام معدات الوقاية الشخصية المناسبة، والتأكد من خلو منطقة العمل من الأخطار قبل البدء."
  },
  {
    keywords: ["رياضيات", "math", "مثلثات", "قياس", "graph", "جبر"],
    answer: "وحدة الرياضيات لفنيي الهندسة تغطي الحسابات الأساسية، BIDMAS، الكسور والأعداد العشرية، الجبر، الرسوم البيانية، القياس، وحساب المثلثات لحل المسائل الهندسية."
  },
  {
    keywords: ["رسم", "drawing", "الرسم الهندسي", "أبعاد", "dimension"],
    answer: "وحدة الرسم الهندسي تركز على قراءة الرسومات، فهم الأبعاد والرموز، واستخدام الرسم كوسيلة أساسية للتواصل الفني داخل التخصصات الهندسية."
  },
  {
    keywords: ["لحام", "welding"],
    answer: "وحدة اللحام تشمل مبادئ اللحام، إجراءات السلامة، أنواع العمليات، وفهم الاستخدامات العملية في البيئات المهنية."
  },
  {
    keywords: ["دوائر", "circuit", "الكترون", "electrical", "مقاومة", "جهد", "تيار"],
    answer: "المحتوى الكهربائي في BTEC يغطي بناء الدوائر الكهربائية والإلكترونية، اختبارها، ومفاهيم مثل الجهد والتيار والمقاومة، إضافة إلى تشغيل وصيانة الأنظمة الكهربائية والإلكترونية."
  },
  {
    keywords: ["مركبات", "سيارات", "vehicle", "صيانة المركبات"],
    answer: "وحدة صيانة المركبات تركز على الفحص والخدمة والصيانة وتشخيص الأعطال ضمن إطار مهني عملي."
  },
  {
    keywords: ["تحسين", "quality", "business improvement", "جودة"],
    answer: "تقنيات تحسين الأعمال في BTEC تهدف إلى رفع الكفاءة، دعم الجودة، وتقليل الهدر وتحسين الأداء داخل العمليات المهنية."
  },
  {
    keywords: ["برمجة", "programming", "code"],
    answer: "وحدة البرمجة العامة تقدم أساسيات التفكير البرمجي، بناء الخوارزميات، والمنطق البرمجي بصورة مناسبة للمسار المهني."
  }
];

function matchAnswer(question) {
  const q = question.toLowerCase();
  const hit = knowledgeBase.find((item) =>
    item.keywords.some((keyword) => q.includes(keyword.toLowerCase()))
  );
  if (hit) return hit.answer;
  return "أنا مساعد BTEC مخصص فقط لمحتوى الهندسة الموجود في المنهج المرفوع. اسألني عن السلامة، الرياضيات الهندسية، المواد الهندسية، الرسم الهندسي، اللحام، الدوائر الكهربائية والإلكترونية، البرمجة، أو صيانة المركبات.";
}

function createUnitCard(unit) {
  const card = document.createElement("div");
  card.className = "unit-card";
  card.dataset.search = `${unit.title} ${unit.summary}`.toLowerCase();
  card.innerHTML = `<h4>${unit.title}</h4><p>${unit.summary}</p>`;
  return card;
}

function createQuestionButton(text, onClick) {
  const btn = document.createElement("button");
  btn.className = "question-chip clickable";
  btn.type = "button";
  btn.textContent = text;
  btn.addEventListener("click", () => onClick(text));
  return btn;
}

function appendMessage(role, text) {
  const messagesBox = document.getElementById("assistant-messages");
  const row = document.createElement("div");
  row.className = `message-row ${role}`;
  const bubble = document.createElement("div");
  bubble.className = `message-bubble ${role}`;
  bubble.textContent = text;
  row.appendChild(bubble);
  messagesBox.appendChild(row);
  messagesBox.scrollTop = messagesBox.scrollHeight;
}

document.addEventListener("DOMContentLoaded", () => {
  const allUnits = [...volume1Units, ...volume2Units];
  const homeUnits = document.getElementById("home-units");
  const materialsGrid = document.getElementById("materials-grid");
  const studentQuestions = document.getElementById("student-questions");
  const assistantQuestions = document.getElementById("assistant-questions");

  allUnits.slice(0, 8).forEach((unit) => homeUnits.appendChild(createUnitCard(unit)));
  allUnits.forEach((unit) => materialsGrid.appendChild(createUnitCard(unit)));
  quickQuestions.forEach((q) => studentQuestions.appendChild(createQuestionButton(q, () => navigateTo("assistant", q))));
  quickQuestions.forEach((q) => assistantQuestions.appendChild(createQuestionButton(q, sendQuestion)));

  appendMessage("assistant", "مرحباً، أنا مساعد BTEC Engineering. أجيب فقط عن محتوى الوحدات الموجودة في الكتب المرفوعة. اكتب سؤالك الآن.");

  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.addEventListener("click", () => navigateTo(btn.dataset.page));
  });

  document.querySelectorAll(".role-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".role-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });

  document.getElementById("open-assistant-btn").addEventListener("click", () => navigateTo("assistant"));
  document.getElementById("view-units-btn").addEventListener("click", () => navigateTo("materials"));
  document.getElementById("ask-now-btn").addEventListener("click", () => navigateTo("assistant"));
  document.getElementById("assistant-send").addEventListener("click", sendQuestion);
  document.getElementById("assistant-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendQuestion();
  });

  document.getElementById("materials-search").addEventListener("input", (e) => {
    const q = e.target.value.trim().toLowerCase();
    materialsGrid.querySelectorAll(".unit-card").forEach((card) => {
      card.classList.toggle("hidden-card", q && !card.dataset.search.includes(q));
    });
  });
});

function navigateTo(page, questionText) {
  document.querySelectorAll(".page-section").forEach((section) => {
    section.classList.toggle("hidden-section", section.dataset.section !== page);
    section.classList.toggle("active-section", section.dataset.section === page);
  });

  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.page === page);
  });

  if (questionText) {
    const input = document.getElementById("assistant-input");
    input.value = questionText;
    sendQuestion();
  }

  window.scrollTo({ top: 0, behavior: "smooth" });
}

function sendQuestion(forcedText) {
  const input = document.getElementById("assistant-input");
  const question = (forcedText ?? input.value).trim();
  if (!question) return;
  appendMessage("user", question);
  appendMessage("assistant", matchAnswer(question));
  input.value = "";
}
